<!doctype html>
<!--[if lt IE 7]><html class="no-js lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->
<!--[if IE 7]><html class="no-js lt-ie9 lt-ie8" lang="en"> <![endif]-->
<!--[if IE 8]><html class="no-js lt-ie9" lang="en"> <![endif]-->
<!--[if IE 9 ]><html class="ie9 no-js"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--> <html> <!--<![endif]-->
<head>
	<meta name="google-site-verification" content="LhfD3BGOFtydvLfGDe5jJwMzmEG2Zwn85Gm-7fuVFdM" />
	<!-- Basic page needs ================================================== -->
	<meta charset="utf-8">

	<!-- Title and description ================================================== -->
	<title>
		404 Không tìm thấy trang &ndash; Thời trang HumMingBird
	</title>

	

	<!-- Product meta ================================================== -->
	

  <meta property="og:url" content="http://hmbfashion.com/tui-xach-thoi-trang-hm073">
  <meta property="og:site_name" content="Thời trang HumMingBird">


	<!-- Helpers ================================================== -->
	<link rel="canonical" href="http://hmbfashion.com/tui-xach-thoi-trang-hm073">
	<meta name="viewport" content="width=device-width,initial-scale=1">

	<!-- Favicon -->
	<link rel="shortcut icon" href="//bizweb.dktcdn.net/100/101/053/themes/130140/assets/favicon.png?1483946676220" type="image/x-icon" />
	<!-- Scripts -->
	<script src='//bizweb.dktcdn.net/100/101/053/themes/130140/assets/jquery.min.js?1483946676220' type='text/javascript'></script> 
<script src='//bizweb.dktcdn.net/100/101/053/themes/130140/assets/bootstrap.min.js?1483946676220' type='text/javascript'></script> 




  
	<!-- Styles -->
	<link href='//bizweb.dktcdn.net/100/101/053/themes/130140/assets/bootstrap.min.css?1483946676220' rel='stylesheet' type='text/css' />
<link href='//bizweb.dktcdn.net/100/101/053/themes/130140/assets/blogmate.css?1483946676220' rel='stylesheet' type='text/css' />
<link href='//bizweb.dktcdn.net/100/101/053/themes/130140/assets/flexslider.css?1483946676220' rel='stylesheet' type='text/css' />
<link href='//bizweb.dktcdn.net/100/101/053/themes/130140/assets/style.css?1483946676220' rel='stylesheet' type='text/css' />
<link href='//bizweb.dktcdn.net/100/101/053/themes/130140/assets/owl.carousel.css?1483946676220' rel='stylesheet' type='text/css' />
<link href='//bizweb.dktcdn.net/100/101/053/themes/130140/assets/animate.css?1483946676220' rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,300,700,800,400,600' rel='stylesheet' type='text/css' />
<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
<link href='//bizweb.dktcdn.net/100/101/053/themes/130140/assets/jgrowl.css?1483946676220' rel='stylesheet' type='text/css' />
	<!-- Header hook for plugins ================================================== -->
	<script>
var Bizweb = Bizweb || {};
Bizweb.store = 'hmbfashion.bizwebvietnam.net';
Bizweb.theme = {"id":130140,"name":"theme_HMB","role":"main","previewable":true,"processing":false,"created_on":"2016-07-06T10:01:48Z","modified_on":"2016-07-21T01:32:13Z"}
Bizweb.template = '404';
</script>

                <script>
                //<![CDATA[
                      (function() {
                        var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true;
                        s.src = '//bizweb.dktcdn.net/assets/themes_support/bizweb_stats.js?v=9';
                        var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
                      })();

                //]]>
                </script>
<noscript><iframe height='0' width='0' style='display:none;visibility:hidden' src='/visit/record.gif?p=%2ftui-xach-thoi-trang-hm073&r=&s=usx3ruzca5eqgvpetrtyg1tb'></iframe></noscript>

<script>
(function() {
function asyncLoad() {
var urls = ["https://facebookinbox.bizwebapps.vn/Script/index?store=hmbfashion.bizwebvietnam.net","//promotionpopup.bizwebapps.vn/genscript/script.js?store=hmbfashion.bizwebvietnam.net","//productreviews.bizwebapps.vn/assets/js/productreviews.min.js?store=hmbfashion.bizwebvietnam.net","https://productquickview.bizwebapps.vn/ScriptTags/productquickview.js?store=hmbfashion.bizwebvietnam.net","https://productviewedhistory.bizwebapps.vn/ProductViewed/ProductRecentScriptTags?store=hmbfashion.bizwebvietnam.net","//bwstatistics.bizwebapps.vn/genscript/script.js?store=hmbfashion.bizwebvietnam.net"];
for (var i = 0; i < urls.length; i++) {
var s = document.createElement('script');
s.type = 'text/javascript';
s.async = true;
s.src = urls[i];
s.src = urls[i];
var x = document.getElementsByTagName('script')[0];
x.parentNode.insertBefore(s, x);
}
}
window.attachEvent ? window.attachEvent('onload', asyncLoad) : window.addEventListener('load', asyncLoad, false);
})();
</script>

<script type='text/javascript'>
(function() {
var log = document.createElement('script'); log.type = 'text/javascript'; log.async = true;
log.src = '//stats.bizweb.vn/delivery/101053.js?lang=vi';
var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(log, s);
})();
</script>

<!-- Google Tag Manager -->
<noscript>
<iframe src='//www.googletagmanager.com/ns.html?id=GTM-MS77Z9' height='0' width='0' style='display:none;visibility:hidden'></iframe>
</noscript>
<script>
(function (w, d, s, l, i) {
w[l] = w[l] || []; w[l].push({
'gtm.start':
new Date().getTime(), event: 'gtm.js'
}); var f = d.getElementsByTagName(s)[0],
j = d.createElement(s), dl = l != 'dataLayer' ? '&l=' + l : ''; j.async = true; j.src =
'//www.googletagmanager.com/gtm.js?id=' + i + dl; f.parentNode.insertBefore(j, f);
})(window, document, 'script', 'dataLayer', 'GTM-MS77Z9');
</script>
<!-- End Google Tag Manager -->

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-84214548-1', 'auto');
  ga('send', 'pageview');

</script>



	<!--[if lt IE 9]>
<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
<![endif]-->
	<!--[if IE 7]>
<link href='//bizweb.dktcdn.net/100/101/053/themes/130140/assets/font-awesome-ie7.css?1483946676220' rel='stylesheet' type='text/css' />
<![endif]-->
	<!--[if lt IE 9]>
<script src='//html5shiv.googlecode.com/svn/trunk/html5.js' type='text/javascript'></script>
<![endif]-->


	

	<link rel="stylesheet" href="//bizweb.dktcdn.net/100/101/053/themes/130140/assets/bizweb-cff-quick-view.css?1483946676220">
<link rel="stylesheet" href="//bizweb.dktcdn.net/100/101/053/themes/130140/assets/bizweb-cff-jquery.fancybox.css?1483946676220">
<link href='//bizweb.dktcdn.net/100/101/053/themes/130140/assets/appbulk-blog-statistics.css?1483946676220' rel='stylesheet' type='text/css' />
	<link href='//bizweb.dktcdn.net/100/101/053/themes/130140/assets/bw-statistics-style.css?1483946676220' rel='stylesheet' type='text/css' />
	<script>var ProductReviewsAppUtil=ProductReviewsAppUtil || {};</script>
	<script>var PromotionPopupAppUtil=PromotionPopupAppUtil || {};</script>
</head>
<body id="404-khong-tim-thay-trang" class="  cms-index-index cms-home-page" >  
	<header>
	<div class="header-container">
		<div class="header-top">
			<div class="container">
				<div class="row">
					<div class="col-sm-4 col-xs-7">           
						<!-- Default Welcome Message -->
						<div class="welcome-msg hidden-xs">Chào mừng bạn đã đến với Thời trang HumMingBird! </div>
						<!-- End Default Welcome Message --> 
					</div>

					<div class="col-sm-8 col-xs-5">
						<div class="row">
							<div class="toplinks">
								<div class="links">
									
									<div><span class="hidden-xs"><a href='/account/login' id='customer_login_link'>Đăng nhập</a></span></div>
									<div><span class="hidden-xs"><a href='/account/register' id='customer_register_link'>Đăng ký</a></span></div>
									
								</div>              
								<!-- links --> 
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="container">
			<div class="row">
				
				<div class="col-lg-3 col-md-3 col-sm-4 col-xs-12"> 
					<div class="search-box">
						<form action="/search" method="get" id="search_mini_form">
							<input type="text" placeholder="Tìm kiếm..." value="" maxlength="70" name="query" id="search">
							<button class="btn btn-default  search-btn-bg"> <span class="fa fa-search"></span>&nbsp;</button>
						</form>
					</div>
				</div>
				
				
				<div class="col-lg-6 col-md-6 col-sm-5 col-xs-12 headerlogo">
					<!-- Header Logo -->
					<div class="logo">
						<a title="Thời trang HumMingBird" href="/">
							
							<img alt="Thời trang HumMingBird" src="//bizweb.dktcdn.net/100/101/053/themes/130140/assets/logo.png?1483946676220">
							
						</a> 
					</div>
					<!-- End Header Logo --> 

				</div>
				
				
				

				<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">

					<div class="addres">
						<div class="addres-box"><strong></strong> 
							<p><span></span></p>
						
						</div>
					</div>
					<div class="phone">
						<div class="phone-box"><strong>Hotline:</strong><p> <span>09 1618 7966</span></p></div>
					</div>
				</div>
			</div>
		</div>
	</div>
</header>
<nav>
	<div class="container">
		<div class="row">

<div class="col-md-9">
				 <div class="nav-inner">
			<!-- mobile-menu -->
			<div class="hidden-desktop" id="mobile-menu">
				<ul class="navmenu">
					<li>
						<div class="menutop">
							<div class="toggle"> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span></div>
							<h2>Menu</h2>
						</div>
						<ul style="display:none;" class="submenu">
							<li>
								<ul class="topnav">
									
									
									<li class="level0 level-top parent"> <a class="level-top" href="/"> <span>Trang chủ</span> </a> </li>
									
									
									
									<li class="level0 level-top parent"> <a class="level-top" href="/gioi-thieu"> <span>Giới thiệu</span> </a> </li>
									
									
									
									<li class="level0 level-top parent"><a class="level-top" href="/collections/all"> <span>Sản phẩm</span> </a>
										<ul class="level0">
											
											
											<li class="level1"> <a href="/san-pham-noi-bat"> <span>Túi xách</span> </a>
												
												
											
											<li class="level1"> <a href="/san-pham-khuyen-mai"> <span>Balo</span> </a>
												
												
											
											<li class="level1"> <a href="/vi-cam-tay"> <span>Ví cầm tay</span> </a>
												
												
											
											<li class="level1"> <a href="/frontpage"> <span>Giày</span> </a>
												
												
										</ul>
									</li>
									
									
									
									<li class="level0 level-top parent"> <a class="level-top" href="/san-pham-khuyen-mai"> <span>Khuyến mãi</span> </a> </li>
									
									
									
									<li class="level0 level-top parent"> <a class="level-top" href="/tin-tuc"> <span>Tin tức</span> </a> </li>
									
									
									
									<li class="level0 level-top parent"> <a class="level-top" href="/lien-he"> <span>Liên hệ</span> </a> </li>
									
									
								</ul>
							</li>
						</ul>
					</li>
				</ul>
			</div>
			<!--End mobile-menu -->
			<ul id="nav" class="hidden-xs">
				
				
				
				
				
				
				<li class="level0 parent "><a href="/"><span>Trang chủ</span></a></li>
				
				
				
				
				
				
				
				<li class="level0 parent "><a href="/gioi-thieu"><span>Giới thiệu</span></a></li>
				
				
				
				
				
				
							
				<li class="level0 parent  "><a href="/collections/all"><span>Sản phẩm</span></a>			  

					
					 <div class="level0-wrapper dropdown-6col">
    <div class="level0-wrapper2">
       <div class="nav-block nav-block-center">
		   <ul class="level0">
		   
			   
			   <li class="level1 item"> <a href="/san-pham-noi-bat"><span>Túi xách</span></a> 
			  
		   
			   
			   <li class="level1 item"> <a href="/san-pham-khuyen-mai"><span>Balo</span></a> 
			  
		   
			   
			   <li class="level1 item"> <a href="/vi-cam-tay"><span>Ví cầm tay</span></a> 
			  
		   
			   
			   <li class="level1 item"> <a href="/frontpage"><span>Giày</span></a> 
			  
		   
		   </ul>
	   </div>
	 </div>
</div>




























  
					
				</li>
				
				
				
				
				
				
				
				<li class="level0 parent "><a href="/san-pham-khuyen-mai"><span>Khuyến mãi</span></a></li>
				
				
				
				
				
				
				
				<li class="level0 parent "><a href="/tin-tuc"><span>Tin tức</span></a></li>
				
				
				
				
				
				
				
				<li class="level0 parent "><a href="/lien-he"><span>Liên hệ</span></a></li>
				
				
			</ul>

		</div>
			</div>
			        <div class="col-md-3">
          <div class="top-cart-contain pull-right"> 
            <!-- Top Cart -->
            <div class="mini-cart">
              <div data-toggle="dropdown" data-hover="dropdown" class="basket dropdown-toggle"> <a href="/cart"> <i class="icon-cart fa fa-shopping-cart"></i>
                <div class="cart-box"><span class="title">Giỏ hàng</span><span id="cart-total">0 sản phẩm </span></div>
                </a></div>
              <div>
                <div style="display: none;" class="top-cart-content arrow_box">
                                 
                  <div class="block-subtitle">Sản phẩm đã cho vào giỏ hàng</div>
                  <ul id="cart-sidebar" class="mini-products-list">
                   
                  </ul>
                  
                 
                </div>
              </div>
            </div>
            <!-- Top Cart -->
            
          </div>
        </div>
	</div>
	</div> 

</nav>  


	<section class="content-wrapper">
  <div class="container">
    <div class="std">
      <div class="page-not-found">
        <h2>404</h2>
        <h3>Không tìm thấy trang mà bạn yêu cầu!</h3>
        <div><a href="/" class="btn-home"><span>Quay lại trang chủ</span></a></div>
      </div>
    </div>
  </div>
</section>


	<link href='//bizweb.dktcdn.net/100/101/053/themes/130140/assets/bpr-products-module.css?1483946676220' rel='stylesheet' type='text/css' />
<div class="bizweb-product-reviews-module"></div>
	<footer>
	
	
	<div class="brand-logo">
		<div class="container">
			
		</div>
	</div>
	
	
	<div class="newsletter-wrap">
		<div class="container">
			<div class="row">
				
				<div class="col-xs-12 col-sm-12 col-md-8">
					<div class="newsletter">
						
						
						
						
						
						
						
						<form accept-charset='UTF-8' action='/contact' id='contact' method='post'>
<input name='FormType' type='hidden' value='contact' />
<input name='utf8' type='hidden' value='true' />

<input id="name" name="contact[Name]" type="text" value="Guest" class="form-control hidden">
<input type="text" class="form-control hidden" name="contact[phone]" value="NaN"  placeholder="Phone number">
<textarea id="message" name="contact[Body]" style="height: 120px;" class="form-control hidden" rows="7">Subcribe Email</textarea>


<input id="email newsletter1" class="input_newsletter input-text required-entry validate-email" name="contact[email]" type="email" value="" class="input_newsletter" placeholder="Email nhận tin" style="width: 45%;">

<button type="submit" class="subscribe"><span>Đăng ký</span></button>

<!-- /input-group -->

									

									</form>
						
						
						
						
						
						
						
						
					</div>
					<!--newsletter--> 
				</div>
				

				<div class="col-xs-12 col-sm-12 col-md-4">
					<div class="inner">
						<div class="social pull-right">
							<ul class="link">
								
								<li class="fb pull-left"><a href="https://www.facebook.com/TuiXachHumMingBird/"></a></li>
								
								
								<li class="tw pull-left"><a href="#"></a></li>
								
								
								<li class="googleplus pull-left"><a href="#"></a></li>
								
								
								<li class="rss pull-left"><a href="#"></a></li>
								
								
								<li class="youtube pull-left"><a href="#"></a></li>
								
							</ul>
						</div>
					</div>
				</div>

			</div>
		</div>
	</div>
	
	<div class="footer-inner">
		<div class="container">
			<div class="row">
				<div class="col-md-3 col-sm-12 col-xs-12 col-lg-3">
					<div class="footer-column-1 pull-left">
						<div class="footer-logo"><a href="/" title="Thời trang HumMingBird">
							
							<img alt="Thời trang HumMingBird" src="//bizweb.dktcdn.net/100/101/053/themes/130140/assets/logo.png?1483946676220">
											
							</a></div>
						<p>Shop chuyên về các mặt hàng giầy và balo, túi xách nữ với đầy đủ phong cách và cá tính. Đảm bảo uy tin - chất lượng - giá cả phải chăng </p>
						
					</div>
				</div>
				
				<div class="col-xs-12 col-sm-6 col-md-2 col-lg-2">
					<div class="footer-column pull-left">
						<h4>Hỗ trợ khách hàng</h4>
						<ul class="links">
							
							<li><a href="/huong-dan" title="Hướng dẫn mua hàng">Hướng dẫn mua hàng</a></li>
							
							<li><a href="/huong-dan" title="Giao nhận và thanh toán">Giao nhận và thanh toán</a></li>
							
							<li><a href="/huong-dan" title="Đổi trả và bảo hành">Đổi trả và bảo hành</a></li>
							
							<li><a href="/huong-dan" title="Đăng kí thành viên">Đăng kí thành viên</a></li>
							
						</ul>
					</div>
				</div>
				
				
				<div class="col-xs-12 col-sm-6 col-md-2 col-lg-2">
					<div class="footer-column pull-left">
						<h4>Chính sách</h4>
						<ul class="links">
							
							<li><a href="/chinh-sach" title="Chính sách thanh toán">Chính sách thanh toán</a></li>
							
							<li><a href="/chinh-sach" title="Chính sách vận chuyển">Chính sách vận chuyển</a></li>
							
							<li><a href="/chinh-sach" title="Chính sách đổi trả">Chính sách đổi trả</a></li>
							
							<li><a href="/chinh-sach" title="Chính sách bảo hành">Chính sách bảo hành</a></li>
							
						</ul>
					</div>
				</div>
				
				
				<div class="col-xs-12 col-sm-6 col-md-2 col-lg-2">
					<div class="footer-column pull-left">
						<h4>Điều khoản</h4>
						<ul class="links">
							
							<li><a href="/dieu-khoan" title="Điều khoản sử dụng">Điều khoản sử dụng</a></li>
							
							<li><a href="/dieu-khoan" title="Điều khoản giao dịch">Điều khoản giao dịch</a></li>
							
							<li><a href="/dieu-khoan" title="Dịch vụ tiện ích">Dịch vụ tiện ích</a></li>
							
							<li><a href="/dieu-khoan" title="Quyền sở hữu trí tuệ">Quyền sở hữu trí tuệ</a></li>
							
						</ul>
					</div>
				</div>
				
				<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
					<div class="footer-column-last pull-left">
						<h4>Liên hệ</h4>
						<address>
							<i class="add-icon">&nbsp;</i>Phan đăng lưu, Phường 1, Quận Phú Nhuận, TP Hồ Chí Minh 
						</address>
						<div class="phone-footer"><i class="phone-icon">&nbsp;</i>09 1618 7966</div>
						<div class="email-footer"><i class="email-icon">&nbsp;</i>phucndd@gmail.com</div>
					</div>
				</div>
			</div>
		</div>
		<div class="footer-bottom">
			<div class="container">
				<div class="row">
					<div class="col-sm-5 col-xs-12 coppyright"> &copy; 2015 - Thời trang HumMingBird. <span class="bizweb">Cung cấp bởi <a href="https://www.bizweb.vn/">Bizweb.</a></span></div>
					<div class="col-sm-7 col-xs-12 company-links">
						<ul class="links">
							<li><a title="Thời trang HumMingBird" href="//hmbfashion.com">Thời trang HumMingBird</a></li>           
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</footer><script>
$(document).ready(function() {
	console.log('aaa');
    $('.actions').css('display','none !important');
});
</script>
	<script src='//bizweb.dktcdn.net/100/101/053/themes/130140/assets/common.js?1483946676220' type='text/javascript'></script>
<script src='//bizweb.dktcdn.net/100/101/053/themes/130140/assets/jquery.flexslider.js?1483946676220' type='text/javascript'></script>
<script src='//bizweb.dktcdn.net/100/101/053/themes/130140/assets/cloud-zoom.js?1483946676220' type='text/javascript'></script>
<script src='//bizweb.dktcdn.net/100/101/053/themes/130140/assets/owl.carousel.min.js?1483946676220' type='text/javascript'></script> 
<script src='//bizweb.dktcdn.net/100/101/053/themes/130140/assets/parallax.js?1483946676220' type='text/javascript'></script>
<script src='//bizweb.dktcdn.net/assets/themes_support/api.jquery.js?4' type='text/javascript'></script>
<script src='//bizweb.dktcdn.net/100/101/053/themes/130140/assets/jgrowl.js?1483946676220' type='text/javascript'></script>
<script src='//bizweb.dktcdn.net/100/101/053/themes/130140/assets/cs.script.js?1483946676220' type='text/javascript'></script>

  

	<script type="text/javascript">
  Bizweb.updateCartFromForm = function(cart, cart_summary_id, cart_count_id) {
    
    if ((typeof cart_summary_id) === 'string') {
      var cart_summary = jQuery(cart_summary_id);
      if (cart_summary.length) {
        // Start from scratch.
        cart_summary.empty();
        // Pull it all out.        
        jQuery.each(cart, function(key, value) {
          if (key === 'items') {
             
            var table = jQuery(cart_summary_id);           
            if (value.length) {           
              jQuery.each(value, function(i, item) {				  
                 jQuery('<li class="item"><a class="product-image" href="' + item.url + '" title="' + item.name + '"><img alt="'+  item.name  + '" src="' + Bizweb.resizeImage(item.image, 'small') +  '"width="'+ '80' +'"\></a><div class="detail-item"><div class="product-details"> <a href="javascript:void(0);" title="Xóa" onclick="Bizweb.removeItem(' + item.variant_id + ')" class="fa fa-remove">&nbsp;</a><p class="product-name"> <a href="' + item.url + '" title="' + item.name + '">' + item.name + '</a></p></div><div class="product-details-bottom"> <span class="price">' + Bizweb.formatMoney(item.price, "{{amount_no_decimals_with_comma_separator}}₫") + '</span> <span class="title-desc">Số lượng:</span> <strong>' +  item.quantity + '</strong> </div></div></li>').appendTo(table);
             				
              }); 
				jQuery('<li><div class="top-subtotal">Tổng cộng: <span class="price">' + Bizweb.formatMoney(cart.total_price, "{{amount_no_decimals_with_comma_separator}}₫") + '</span></div></li>').appendTo(table);
			
              jQuery('<li style="margin-left:-15px;margin-right:-15px;"><div class="actions"><button class="btn-checkout" type="button" onclick="window.location.href=\'/checkout\'"><span>Thanh toán</span></button><button class="view-cart" type="button" onclick="window.location.href=\'/cart\'" ><span>Giỏ hàng</span></button></div></li>').appendTo(table);
              
            }
            else {
              jQuery('<li class="item"><p>Không có sản phẩm nào trong giỏ hàng.</p></li>').appendTo(table);
				
            }
			  
          }
        });
		
      }
    }
	  updateCartDesc(cart);
  }

  
  function updateCartDesc(data){
    var $cartLinkText = $('.mini-cart .cart-box #cart-total, aside.sidebar .block-cart .amount a'),
		
	    $cartPrice = Bizweb.formatMoney(data.total_price, "{{amount_no_decimals_with_comma_separator}}₫");		
    switch(data.item_count){
      case 0:
        $cartLinkText.text('0 sản phẩm');
		
        break;
      case 1:
        $cartLinkText.text('1 sản phẩm');
		
        break;
      default:
        $cartLinkText.text(data.item_count + ' sản phẩm');
		
        break;
    }
	 $('.top-cart-content .top-subtotal .price, aside.sidebar .block-cart .subtotal .price').html($cartPrice);
  }  
  Bizweb.onCartUpdate = function(cart) {
    Bizweb.updateCartFromForm(cart, '.top-cart-content .mini-products-list', 'shopping-cart');
  };  
  $(window).load(function() {
    // Let's get the cart and show what's in it in the cart box.  
    Bizweb.getCart(function(cart) {      
      Bizweb.updateCartFromForm(cart, '.top-cart-content .mini-products-list');    
    });
  });
</script>
	<a href="#" id="toTop" style="display: block;"><span id="toTopHover" style="opacity: 0;"></span></a>
	<div id="biz-qv-showqv" style="display: none !important;">  
 <div itemscope itemtype="http://schema.org/Product">


	<!--START PRODUCT-->
	 <div class="quick-view-container fancyox-view-detail">
	    <div id="biz-qv-left" class="biz-left">
            <div id="biz-qv-sale"  class="biz-qv-sale biz-qv-hidden">Sale</div>
			<!-- START ZOOM IMAGE-->
			 <div class="biz-qv-zoom-container">
                    <div class="zoomWrapper">
					  <div id="biz-qv-zoomcontainer" class='sqa-qv-zoomcontainer'>
                              <!-- Main image  ! DON'T PUT CONTENT HERE! -->     
                      </div>
                       
                    </div>
             </div>
			<!-- END ZOOM IMAGE-->
          
            <!-- START GALLERY-->
            <div id="biz-qv-galleryid" class="biz-qv-gallery" style="position: absolute; bottom: 10px;left: 6%;"> 
              		<!-- Collection of image ! DON'T PUT CONTENT HERE!-->
            </div>	
            <!-- END GALLERY-->
        </div>

		<!--START BUY-->
		<div id ="biz-qv-right" class="biz-right">
          	<!-- -------------------------- -->
			<div id="biz-qv-title" class="name-title" >
					<!-- Title of product ! DON'T PUT CONTENT HERE!-->
			</div>
			<!-- -------------------------- -->
			<div id ="biz-qv-price-container" class="biz-qv-price-container"  >
					<!-- price information of product ! DON'T PUT CONTENT HERE!-->
			</div>
			<!-- -------------------------- -->
			<div id="biz-qv-des" class="biz-qv-row">
					<!-- description of product ! DON'T PUT CONTENT HERE!-->
			</div>
			<!-- -------------------------- -->
			<div class="biz-qv-row">
				<a id="biz-qv-detail"  href="" >  </a>
			</div>
		<!-- ----------------------------------------------------------------------- -->
            <div id='biz-qv-cartform'>
	          <form id="biz-qv-add-item-form"  method="post">     
                <!-- Begin product options ! DON'T PUT CONTENT HERE!-->
                <div class="biz-qv-product-options">
                  <!-- -------------------------- -->
                  <div id="biz-qv-variant-options" class="biz-qv-optionrow">
							<!-- variant options  of product  ! DON'T PUT CONTENT HERE!-->
		          </div>  
                  <!-- -------------------------- -->
                  <div class="biz-qv-optionrow">	    
                    <label>Số lượng</label>
          	        <input id="biz-qv-quantity" min="1" type="number" name="quantity" value="1"  />
                  </div>
				  <!-- -------------------------- -->
                  <div class="biz-qv-optionrow">
                     <p id="biz-qv-unavailable" class="biz-sold-out biz-qv-hidden">Không sẵn có</p>
                     <p id="biz-qv-sold-out" class="biz-sold-out biz-qv-hidden">Hết hàng</p>
                     <input type="submit" class="biz-qv-cartbtn biz-qv-hidden" value="Thêm vào giỏ hàng" />
                     
                  </div>
                  <!-- -------------------------- -->					
									
                </div>
               <!-- End product options -->
            </form>
         </div>

	   </div>
	   <!--END BUY-->
    </div>
	<!--END PRODUCT-->
 </div>
</div>


<div id="bizqv-metadata" 
autoconfig = "yes" 
noimage = "//bizweb.dktcdn.net/100/101/053/themes/130140/assets/cff-qv-no-image.jpg?1483946676220" 
moneyFormat = "{{amount_no_decimals_with_comma_separator}}₫" 
jsondata = "eyJxdl9kaXNhYmxlIjpmYWxzZSwiYm50X3RleHQiOiJYZW0gbmhhbmgiLCJibnRfdGV4dF9mb250IjoiQXJpYWwiLCJibnRfdGV4dF9mb250X3NpemUiOiIxNnB4IiwiYnRuX3RleHRfY29sb3IiOiIjQ0NDQ0ZGIiwiYm50X3RleHRfaG92ZXIiOiIjRkZGRkZGIiwiYm50X2NvbG9yIjoiIyMwMDAwNjYiLCJibnRfY29sb3JfaG92ZXIiOiIjMDQzOEJEIiwid2Rfd2lkdGgiOiI4MDAiLCJ3ZF9oZWlnaHQiOiI1MDAiLCJpbWdfbWFpbl93aWR0aCI6IjM0NSIsInRpdGxlX2NvbG9yIjoiIzAwMDAwMCIsInByaWNlX2NvbG9yIjoiI0ZGMDAwMCIsImxpbmtfY29sb3IiOiIjNTU4RUQ1IiwiY2FydF9jb2xvciI6IiNGMDRCMDciLCJjYXJ0X3RleHRfY29sb3IiOiIjRkZGRkZGIiwiY2FydGNvdW50IjoiI2NhcnQtY291bnR8LmNhcnQtdG90YWx8I2NhcnQtdG90YWx8I21pbmljYXJ0ICNjYXJ0LXRhcmdldC1kZXNrdG9wfCNkcmF3ZXIgLmNvbnRhaW5lcnwud3JhcHBlciAuaGVhZGVyLWNhcnQtYnRufCNjYXJ0LXRvdGFsICNjYXJ0LXByaWNlfCNjYXJ0LWNvdW50IC5uby11bmRlcmxpbmV8LmZyIC5jYXJ0IC50b3RhbF9wcmljZXwudW5zdHlsZWQgLmZyIC5jYXJ0fC53cmFwcGVyICNjYXJ0VG9nZ2xlfCN1bWJyZWxsYSAuY2FydC1saW5rIC5pY29ufCNtaW5pLWNhcnQgI2NhcnQtdGFyZ2V0fC50b29sYmFyLXdyYXBwZXIgLnVuc3R5bGVkIiwiY2FydF9ub3RpZnlfYWRkX2Zvcm1hdCI6IlPhuqNuIHBo4bqpbSDEkcOjIMSRxrDhu6NjIHRow6ptIHRow6BuaCBjw7RuZyB2w6BvICpHaeG7jyBow6BuZyUgISIsImNhcnRfbm90aWZ5X2luX2Zvcm1hdCI6IlPhuqNuIHBo4bqpbSBuw6B5IMSRw6MgY8OzIHPhurVuIHRyb25nICpHaeG7jyBow6BuZyUhICIsInZpZXdfZGV0YWlsX3RleHQiOiJYZW0gY2hpIHRp4bq/dCBz4bqjbiBwaOG6qW0ifQ==" >
</div>

	<div id="share_us2">
		<iframe allowtransparency="true" frameborder="0" scrolling="no" src="//www.facebook.com/plugins/likebox.php?href=https://www.facebook.com/TuiXachHumMingBird/?fref=ts;width=240&amp;height=258&amp;colorscheme=light&amp;show_faces=true&amp;header=false&amp;stream=false&amp;show_border=false" style="border:none; overflow:hidden; width:240px; height:258px; background:#fff;  border: 2px solid #4465B1;"></iframe>

	</div>


	<div id="facebook-inbox">
	<button class="facebook-inbox-tab" style="display: block; ">
		<span class="facebook-inbox-tab-icon">
			<img src="https://facebookinbox.bizwebapps.vn/Content/Images/fb-icon-1.png" alt="Facebook Chat" />
		</span>
		<span class="facebook-inbox-tab-title">chat với chúng tôi</span>
	</button>

	<div id="facebook-inbox-frame">
		<div id="fb-root">&nbsp;</div>
		<div class="fb-page" data-adapt-container-width="true" data-hide-cover="false" data-href="" data-show-facepile="true" data-small-header="true" data-width="250" data-height="350" data-tabs="messages">
			<div class="fb-xfbml-parse-ignore">
				<blockquote cite=""><a href="">Chat với chúng tôi</a></blockquote>
			</div>
		</div>
	</div>
</div>

<style>
	#facebook-inbox {
		position: fixed;
		bottom: 0px;
		z-index: 110000;
		text-align: center;
		display: none;
	}

	.facebook-inbox-tab-icon {
		float: left;
	}

	.facebook-inbox-tab-title {
		float: left;
		margin-left: 10px;
		line-height: 25px;
	}

	#facebook-inbox-frame {
		display: none;
		width: 100%;
		min-height: 200px;
		overflow: hidden;
		position: relative;
		background-color: #f5f5f5;
	}

	#fb-root {
		height: 0px;
	}

	.facebook-inbox-tab {
		top: 0px;
		bottom: 0px;
		margin: -40px 0px 0px 0px;
		position: relative;
		height: 40px;
		width: 250px;
		border: 1px solid;
		border-radius: 0px 0px 0px 0px;
		text-align: center;
		background-color: #19a3dd;
		color: #ffffff;
	}
</style>
<script>
(function (d, s, id) {
				var js, fjs = d.getElementsByTagName(s)[0];
				if (d.getElementById(id)) return;
				js = d.createElement(s); js.id = id;
				js.src = "//connect.facebook.net/vi_VN/sdk.js#xfbml=1&version=v2.5";
				fjs.parentNode.insertBefore(js, fjs);
		}(document, 'script', 'facebook-jssdk'));
	window.facebookParse = function facebookParse(){
		FB.XFBML.parse();
	}
</script>
<a href="tel: 09 1618 7966" class="hotline-fixed-mobile hidden-lg hidden-md hidden-sm"><i class="fa fa-phone"></i> Gọi ngay</a>
</body>



<!-- Facebook Pixel Code -->
<script>

	// ViewContent
	// Track key page views (ex: product page, landing page or article)
	fbq('track', 'ViewContent');



	!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
		n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
							 n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
							 t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
																									document,'script','//connect.facebook.net/en_US/fbevents.js');

	fbq('init', '1081617401849401');
	fbq('track', "PageView");</script>
<noscript><img height="1" width="1" style="display:none"
			   src="https://www.facebook.com/tr?id=1081617401849401&ev=PageView&noscript=1"
			   /></noscript>
<!-- End Facebook Pixel Code -->

<!-- Google Code for VSG Solution - Tracking Conversion Page -->
<script type="text/javascript">
	/* <![CDATA[ */
	var google_conversion_id = 985148654;
	var google_conversion_language = "vi";
	var google_conversion_format = "3";
	var google_conversion_color = "ffffff";
	var google_conversion_label = "g5WuCOfmnWMQ7tng1QM";
	var google_remarketing_only = false;
	/* ]]> */
</script>
<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
	<div style="display:inline;">
		<img height="1" width="1" style="border-style:none;" alt="" src="//www.googleadservices.com/pagead/conversion/985148654/?label=g5WuCOfmnWMQ7tng1QM&amp;guid=ON&amp;script=0"/>
	</div>
</noscript>


</html>